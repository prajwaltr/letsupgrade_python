num =input("Input:")
num =int(num)
if num<1000 :
   print("Safe to land")
elif 1000<num<5000 :
   print("Bring down to 1000")
else :
   print("go around and turn later")
