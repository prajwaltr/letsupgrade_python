t=(1,2,4,3,5,7,6,3)
print(t)

print(t[0])

print(t[-1])

print(t[2:5])

print(t.count(3))

print(t.index(3))
