txt="    hello nice to meet you   "
print(txt.capitalize())

print(txt.casefold())

print(txt.encode())

print(txt.endswith("u"))

print(txt.find('n')) #txt.index('n')

print(txt.isalnum())

print(txt.isalpha())

print(txt.lstrip())

print(txt.rfind('hello'))

print(txt.rsplit("hello, "))

print(txt.swapcase())

print(txt.strip())
