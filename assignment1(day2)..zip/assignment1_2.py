d = {1:'a' ,2:'b' ,3:'c' ,'d':5 ,4:'e'}
print(d)

print(d.get(1))

d['d']=6
print(d)

print(d.pop(2))
print(d)

print(d.popitem())
print(d)

print(d.values())

d1={4:'f'}
d.update(d1)
print(d)

d1={5:'e'}
d.update(d1)
print(d)
