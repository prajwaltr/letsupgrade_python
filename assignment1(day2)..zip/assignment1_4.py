s={1,3,2,6,4,5}
print(s)

s.add(7)
print(s)

s.update([3,2,1])
print(s)

s.remove(1)  #s.discard(1)
print(s)

s.pop()
print(s)

s.clear()
print(s)
