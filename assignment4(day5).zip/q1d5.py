lst =[]
n = int(input("Enter the number of elements: "))
for i in range(0,n):
    ele =int(input())
    lst.append(ele)
#print(lst)
l =[1,1,5]
def check(lst,l):
   if lst==l:
       print("its a match")
   elif len(lst)<len(l):
       print("its gone")
   else:
       for i in range(len(lst)):
           if lst[i]==l[0]:
               n=i+1
               while (n<len(lst)-i) and (lst[i+n]==l[1]):
                    n+=1
               x=n+1
               while (x<len(lst)-n) and (lst[i+x]==l[2]):
                         x+=1
               if x==len(l):
                  print("its a match")
           else:
               print("its gone")
