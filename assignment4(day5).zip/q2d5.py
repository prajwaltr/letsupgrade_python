lst=list(range(1,2500))
def checkprime(num):
     if num > 1:
        for i in range(2,num):
           if (num % i) == 0:
                return False
                break
        else:
            return True

     else:
        return False
lst_prime=[]
lst_prime1= filter(checkprime,lst)
#for item in lst:
    #if checkprime(item):
        #lst_prime.append(item)
print(list(lst_prime1))
