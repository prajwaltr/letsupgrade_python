string = "hey this is  sai,i am in mumbai,..."
words=string.split()
n=len(words)
print(words)
for i in range(n):
    dolamda= lambda words[i] :words[i].upper()
print(words)
