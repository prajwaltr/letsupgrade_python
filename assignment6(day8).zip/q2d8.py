fh=open("something.txt","w+")
fh.write(input())
#fh.close()
try:
    fh=open("something.txt","r")
    fh.write("can i write")
    print(fh.read())
    #fh.close()
except:
    print("NOTE:u can't wirte when file is opened in read mode")
fh.close()
