def fibonacci(func):
    def series(x):
        if x<=0:
            print("invalid input")
        elif x==1:
            print("0")
        else:
            return func(x)
    return series

@fibonacci
def num(n):
    n1,n2=0,1
    count=0
    print("Fibonacci sequence:")
    while count<n:
        print(n1)
        up=n1+n2
        n1=n2
        n2=up
        count +=1
#c=input("Enter how many terms to print:")
num(int(input("how many numbers:")))
