import math
class cone:
    def __init__(self):
        self.r =float(input("Enter radius:"))
        self.h =float(input("Enter height:"))
        #print("Entered radius is:",self.r" and height is:",self.h)
    def vol(self):
        volume = math.pi *(self.r**2)*(self.h/3)
        print("volume of the cone is:",volume)
    def area(self):
        base=math.pi*(self.r**2)
        x=(self.r**2)+(self.h**2)
        side=math.pi*(self.r)*math.sqrt(x)
        area=base+side
        print("surface area is:",area)
obj=cone()
obj.vol()
obj.area()
