class bankdetails:
    def __init__(self,ownername):
          self.name=ownername
          self.balance = 0
          print("hello "+self.name + " welcome to xyz bank ATM")
    def deposit(self):
        amount = float(input("\nEnter the amount to be deposited: "))
        self.balance +=amount
        print("Amount deposited:",amount)
    def withdraw(self):
        amount = float(input("\nEnter the amount to be withdrawn:"))
        if self.balance >=amount:
            self.balance -=amount
            print("Amount withdrawn: ",amount)
        else:
            print("\nInsufficient balance")
    def display(self):
        print("\n Net avaliable balance: ",self.balance)

name = str(input())
acc=bankdetails(name)
acc.deposit()
acc.withdraw()
acc.display()
