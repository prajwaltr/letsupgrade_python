def armstrong(lst):
    for num in lst:
        l=len(str(num))
        temp = num
        sum=0
        while temp>0:
            x=temp%10
            sum+=x**l
            temp//=10  #temp =temp//10 [ex-> 121//10=12]
        if num == sum:
            yield num

lst=list(range(1,1001))
print(list(armstrong(lst)))
