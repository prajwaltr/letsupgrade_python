import module
import unittest
module.prime(5)

class testcheckprime(unittest.Testcase):
    def one(self):
        result =module.prime(5)
        self.assertEquals(result,"5  is a Prime number")
if __name__ =="__main__":
    unittest.main()
#! python testcheckprime.py
