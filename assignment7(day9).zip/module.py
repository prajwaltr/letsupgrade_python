#%%writefile check_prime.py
'''
Program to check prime number
'''
def prime(num):
    '''
    Actual code
    '''
    if num<1:
        print("invalid input")
    elif num==1:
        print(num," is not a Prime number")
    else:
        for i in range(2,num):
            if num%i==0:
                print(num," is not a Prime number")
                break
        else:
            print(num," is a Prime number")
#prime(int(input("Enter the number:")))
